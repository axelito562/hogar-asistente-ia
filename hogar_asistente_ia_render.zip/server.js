import express from "express";
import OpenAI from "openai";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

app.post("/api/chat", async (req, res) => {
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({ error: "Mensaje vacío." });

    const response = await client.responses.create({
      model: "gpt-5.6-luna",
      instructions: "Sos un asistente virtual amable, claro y útil. Respondé en español.",
      input: message
    });

    res.json({ answer: response.output_text });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "No se pudo obtener una respuesta de la IA." });
  }
});

app.listen(process.env.PORT || 3000, () => {
  console.log(`Hogar del asistente: http://localhost:${process.env.PORT || 3000}`);
});
