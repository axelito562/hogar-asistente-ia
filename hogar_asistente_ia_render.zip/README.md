# Hogar del asistente con IA y voz

## 1. Instalar
Necesitás Node.js instalado.

## 2. Instalar dependencias
En esta carpeta:
npm install

## 3. Configurar la clave
Creá un archivo llamado `.env` con:
OPENAI_API_KEY=tu_clave

NO pongas la clave dentro de `public/index.html` ni la publiques en GitHub.

## 4. Ejecutar
npm start

Abrí:
http://localhost:3000

Al tocar 🎙️, el navegador pedirá permiso para usar el micrófono. La voz se convierte en texto en el navegador, se manda al servidor, el servidor consulta la IA y la respuesta se muestra y se lee en voz alta.

Para publicarlo en Internet necesitás un hosting que permita Node.js y variables de entorno.
